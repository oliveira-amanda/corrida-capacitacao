import googleIconImg from '../../assets/google-icon.svg';
import loginImg from '../../assets/login-img.svg';
import { useAuth } from '../../hooks/useAuth';
import { Container, LeftSide, RightSide } from './styles';

export const SignIn = () => {
  const { user, signInWithGoogle } = useAuth();
  
  const handleLogin = () => {
    if(!user) {
      signInWithGoogle();
    }
  }

  return (
    <Container>
      <LeftSide>
        <img src={loginImg} alt="Pessoa subindo escada de livros" />
        <p>Registre e compartilhe seu <strong>estudo</strong> e acompanhe os do seus colegas.</p>
      </LeftSide>
      <RightSide>  
        <h2>Corrida da Capacitação</h2>
        <button onClick={handleLogin} className="">
          <img src={googleIconImg} alt="Logo do Google" />
          Entrar com o Google
        </button>
      </RightSide>
    </Container>
  )
}