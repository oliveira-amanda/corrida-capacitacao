import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
	align-items: stretch;
	height: 100vh;
`;

export const RightSide = styled.aside`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;

  @media (min-width: 1000px) {
    max-width: 520px; 
  }

  h2 {
    font-size: 1.5rem;
    margin-top: 1em;
    color: var(--primary-blue);
  }

  button {
    display: flex;
		justify-content: center;
		align-items: center;
    
    width: 20em;
    margin-top: 64px;
		height: 50px;
		border-radius: 8px;
    border: 0;
		font-weight: 500;
    font-size: 16px;
    background: var(--primary-blue);
		color: var(--white);

		transition: filter 0.2s;

		img {
			margin-right: 8px;
		}

		&:hover {
			filter: brightness(0.9);
		}
  }
`;

export const LeftSide = styled.section`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  background: var(--primary-green);

  img {
    max-width: 500px;
  }

  p {
    max-width: 18em;
    font-size: 1.2rem;
    text-align: center;
    margin-top: 1.5em;
    color: var(--white);
  }

  strong {
    font-size: 1.3rem;
  }

  @media (max-width: 1000px) {
    display: none;
  }
`;

