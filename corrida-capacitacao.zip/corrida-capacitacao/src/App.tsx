import { BrowserRouter, Route, Switch } from 'react-router-dom';
import React from 'react';
import { AuthContextProvider } from './contexts/AuthContext';
import { SignIn } from './pages/SignIn';
import { GlobalStyle } from './styles/global';

function App() {
  return (
    <BrowserRouter>
      <AuthContextProvider>
        <Switch>
          <Route path='/' component={SignIn} />
        </Switch>
      </AuthContextProvider>
      <GlobalStyle />
    </BrowserRouter>
  );
}

export default App;
