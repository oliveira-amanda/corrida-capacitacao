import firebase from 'firebase/compat/app';
import 'firebase/compat/database'
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBHfIc9fA1DX3XG0ubdULLbPWLLC9SNrms",
  authDomain: "corrida-da-capacitacao.firebaseapp.com",
  databaseURL: "https://corrida-da-capacitacao-default-rtdb.firebaseio.com",
  projectId: "corrida-da-capacitacao",
  storageBucket: "corrida-da-capacitacao.appspot.com",
  messagingSenderId: "283900972101",
  appId: "1:283900972101:web:6981595975b4f20efca72c"

};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const database = firebase.database();

export { auth, database, firebase }